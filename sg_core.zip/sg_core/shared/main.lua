SgCoreVersion = "1.0.0"

SgCoreFrameworks = {
    "sg",
    "esx",
    "qb",
    "qbox",
    "nd"
}
