Config = {
    CoreName = "sg_core",
    PersistenceFile = "player-data.json",
    CallbackTimeout = 10000,
    StartingMoney = {
        cash = 500,
        bank = 2500,
        black_money = 0
    },
    DefaultJob = {
        name = "unemployed",
        label = "Unemployed",
        grade = 0,
        gradeName = "unemployed",
        gradeLabel = "Unemployed",
        onduty = false
    },
    Debug = false
}
