local playerStore = {}
local savedPlayers = {}
local serverCallbacks = {}
local clientCallbacks = {}
local pendingClientCallbacks = {}
local usableItems = {}
local clientCallbackSequence = 0

local RESOURCE_NAME <const> = GetCurrentResourceName()
local CALLBACK_TIMEOUT <const> = Config.CallbackTimeout

local function debugPrint(message)
    if Config.Debug then
        print(("[%s] %s"):format(RESOURCE_NAME, message))
    end
end

local function getIdentifiers(source)
    local identifiers = {}

    for _, identifier in ipairs(GetPlayerIdentifiers(source)) do
        local identifierType = identifier:match("^([^:]+):")
        if identifierType then
            identifiers[identifierType] = identifier
        end
    end

    return identifiers
end

local function getPrimaryIdentifier(source)
    local identifiers = getIdentifiers(source)
    return identifiers.license or identifiers.license2 or identifiers.fivem or identifiers.steam or identifiers.ip
end

local function isValidSource(source)
    return type(source) == "number" and source > 0 and GetPlayerName(source) ~= nil
end

local function cloneValue(value)
    if type(value) ~= "table" then
        return value
    end

    local copy = {}
    for key, child in pairs(value) do
        copy[key] = cloneValue(child)
    end

    return copy
end

local function isValidAccount(account)
    return account == "cash" or account == "bank" or account == "black_money"
end

local function normalizeMoney(money)
    local result = cloneValue(Config.StartingMoney)

    if type(money) == "table" then
        for account in pairs(result) do
            local value = tonumber(money[account])
            if value then
                result[account] = math.max(0, math.floor(value))
            end
        end
    end

    return result
end

local function normalizeJob(job)
    local result = cloneValue(Config.DefaultJob)

    if type(job) == "table" then
        result.name = tostring(job.name or result.name)
        result.label = tostring(job.label or result.label)
        result.grade = tonumber(job.grade) or result.grade
        result.gradeName = tostring(job.gradeName or job.grade_name or result.gradeName)
        result.gradeLabel = tostring(job.gradeLabel or job.grade_label or result.gradeLabel)
        result.onduty = job.onduty == true or job.onduty == 1 or job.onduty == "1"
    end

    return result
end

local function normalizeSavedData(identifier, data)
    data = type(data) == "table" and data or {}

    return {
        identifier = identifier,
        citizenid = tostring(data.citizenid or identifier),
        license = data.license or identifier,
        name = tostring(data.name or "Unknown"),
        money = normalizeMoney(data.money),
        job = normalizeJob(data.job),
        metadata = type(data.metadata) == "table" and cloneValue(data.metadata) or {},
        inventory = type(data.inventory) == "table" and cloneValue(data.inventory) or {}
    }
end

local function savePlayer(player)
    if not player or not player.data or not player.data.identifier then
        return false
    end

    local data = cloneValue(player.data)
    data.source = nil
    savedPlayers[player.data.identifier] = data
    return true
end

local function saveAllPlayers()
    for _, player in pairs(playerStore) do
        savePlayer(player)
    end

    local encoded = json.encode(savedPlayers)
    local success = SaveResourceFile(RESOURCE_NAME, Config.PersistenceFile, encoded, -1)
    if not success then
        print(("[%s] Failed to save %s"):format(RESOURCE_NAME, Config.PersistenceFile))
    end
end

local function loadSavedPlayers()
    local content = LoadResourceFile(RESOURCE_NAME, Config.PersistenceFile)
    if not content or content == "" then
        return
    end

    local success, decoded = pcall(json.decode, content)
    if success and type(decoded) == "table" then
        savedPlayers = decoded
        debugPrint(("Loaded %s persisted player records"):format(tostring(#decoded)))
    else
        print(("[%s] Ignoring invalid persistence data in %s"):format(RESOURCE_NAME, Config.PersistenceFile))
    end
end

local function sendPlayerData(source, player)
    if not player then
        return
    end

    local data = player:getData()
    TriggerClientEvent("sg_core:client:playerLoaded", source, data)
    TriggerClientEvent("esx:playerLoaded", source, data)
    TriggerClientEvent("QBCore:Client:OnPlayerLoaded", source, data)
    TriggerClientEvent("QBCore:Player:SetPlayerData", source, data)
end

local function createPlayer(source)
    if not isValidSource(source) then
        return nil
    end

    local identifier = getPrimaryIdentifier(source)
    if not identifier then
        print(("[%s] Refused to create player %s without an identifier"):format(RESOURCE_NAME, tostring(source)))
        return nil
    end

    if playerStore[source] then
        return playerStore[source]
    end

    local data = normalizeSavedData(identifier, savedPlayers[identifier])
    data.source = source
    data.name = GetPlayerName(source) or data.name
    data.license = getIdentifiers(source).license or data.license

    local player = {
        data = data,
        Functions = {}
    }

    function player:getData()
        return cloneValue(self.data)
    end

    function player:GetData()
        return self:getData()
    end

    function player:getIdentifier()
        return self.data.identifier
    end

    function player:GetIdentifier()
        return self:getIdentifier()
    end

    function player:getName()
        return self.data.name
    end

    function player:GetName()
        return self:getName()
    end

    function player:getSource()
        return self.data.source
    end

    function player:GetSource()
        return self:getSource()
    end

    function player:getMoney()
        return self.data.money.cash
    end

    function player:GetMoney()
        return self:getMoney()
    end

    function player:getAccount(account)
        if not isValidAccount(account) then
            return { name = account, money = 0 }
        end

        return {
            name = account,
            money = self.data.money[account]
        }
    end

    function player:GetAccount(account)
        return self:getAccount(account)
    end

    function player:addMoney(amount, account, reason)
        account = account or "cash"
        amount = math.floor(tonumber(amount) or 0)
        if not isValidAccount(account) or amount <= 0 then
            return false
        end

        self.data.money[account] = self.data.money[account] + amount
        debugPrint(("Added %s %s to %s (%s)"):format(amount, account, self.data.name, tostring(reason or "unspecified")))
        return true
    end

    function player:AddMoney(account, amount, reason)
        return self:addMoney(amount, account, reason)
    end

    function player:addAccountMoney(account, amount, reason)
        return self:addMoney(amount, account, reason)
    end

    function player:AddAccountMoney(account, amount, reason)
        return self:addMoney(amount, account, reason)
    end

    function player:removeMoney(amount, account, reason)
        account = account or "cash"
        amount = math.floor(tonumber(amount) or 0)
        if not isValidAccount(account) or amount <= 0 or self.data.money[account] < amount then
            return false
        end

        self.data.money[account] = self.data.money[account] - amount
        debugPrint(("Removed %s %s from %s (%s)"):format(amount, account, self.data.name, tostring(reason or "unspecified")))
        return true
    end

    function player:RemoveMoney(account, amount, reason)
        return self:removeMoney(amount, account, reason)
    end

    function player:removeAccountMoney(account, amount, reason)
        return self:removeMoney(amount, account, reason)
    end

    function player:RemoveAccountMoney(account, amount, reason)
        return self:removeMoney(account, amount, reason)
    end

    function player:setJob(name, grade, label, gradeName)
        name = tostring(name or "unemployed")
        grade = tonumber(grade) or 0
        self.data.job = {
            name = name,
            label = tostring(label or name),
            grade = grade,
            gradeName = tostring(gradeName or grade),
            gradeLabel = tostring(gradeName or grade),
            onduty = self.data.job.onduty == true
        }

        TriggerClientEvent("sg_core:client:jobUpdated", self.data.source, cloneValue(self.data.job))
        TriggerClientEvent("esx:setJob", self.data.source, cloneValue(self.data.job))
        TriggerClientEvent("QBCore:Player:SetPlayerData", self.data.source, self:getData())
        return true
    end

    function player:SetJob(name, grade)
        return self:setJob(name, grade)
    end

    function player:getJob()
        return cloneValue(self.data.job)
    end

    function player:GetJob()
        return self:getJob()
    end

    function player:setMetaData(key, value)
        if type(key) ~= "string" or #key < 1 or #key > 64 then
            return false
        end

        self.data.metadata[key] = cloneValue(value)
        TriggerClientEvent("QBCore:Player:SetPlayerData", self.data.source, self:getData())
        return true
    end

    function player:SetMetaData(key, value)
        return self:setMetaData(key, value)
    end

    function player:getMetaData(key)
        return cloneValue(self.data.metadata[key])
    end

    function player:GetMetaData(key)
        return self:getMetaData(key)
    end

    function player:addItem(itemName, amount, metadata)
        itemName = tostring(itemName or "")
        amount = math.floor(tonumber(amount) or 0)
        if itemName == "" or amount <= 0 then
            return false
        end

        local item = self.data.inventory[itemName]
        if type(item) ~= "table" then
            item = { name = itemName, amount = 0, metadata = {} }
            self.data.inventory[itemName] = item
        end

        item.amount = item.amount + amount
        if metadata ~= nil then
            item.metadata = cloneValue(metadata)
        end

        return true
    end

    function player:AddItem(itemName, amount, metadata)
        return self:addItem(itemName, amount, metadata)
    end

    function player:removeItem(itemName, amount)
        itemName = tostring(itemName or "")
        amount = math.floor(tonumber(amount) or 0)
        local item = self.data.inventory[itemName]
        if not item or amount <= 0 or item.amount < amount then
            return false
        end

        item.amount = item.amount - amount
        if item.amount <= 0 then
            self.data.inventory[itemName] = nil
        end

        return true
    end

    function player:RemoveItem(itemName, amount)
        return self:removeItem(itemName, amount)
    end

    function player:getItem(itemName)
        local item = self.data.inventory[itemName]
        return item and cloneValue(item) or { name = itemName, amount = 0, metadata = {} }
    end

    function player:GetItem(itemName)
        return self:getItem(itemName)
    end

    function player:getInventoryItem(itemName)
        local item = self:getItem(itemName)
        item.count = item.amount
        return item
    end

    function player:getInventory()
        return cloneValue(self.data.inventory)
    end

    function player:hasItem(itemName, amount)
        return self.data.inventory[itemName] ~= nil and self.data.inventory[itemName].amount >= (tonumber(amount) or 1)
    end

    function player:save()
        return savePlayer(self)
    end

    player.Functions.GetData = function()
        return player:getData()
    end
    player.Functions.GetMoney = function(account)
        return account and player:getAccount(account).money or player:getMoney()
    end
    player.Functions.AddMoney = function(account, amount, reason)
        return player:addMoney(amount, account, reason)
    end
    player.Functions.RemoveMoney = function(account, amount, reason)
        return player:removeMoney(amount, account, reason)
    end
    player.Functions.SetJob = function(job, grade)
        return player:setJob(job, grade)
    end
    player.Functions.GetJob = function()
        return player:getJob()
    end
    player.Functions.SetMetaData = function(key, value)
        return player:setMetaData(key, value)
    end
    player.Functions.GetMetaData = function(key)
        return player:getMetaData(key)
    end
    player.Functions.AddItem = function(itemName, amount, metadata)
        return player:addItem(itemName, amount, metadata)
    end
    player.Functions.RemoveItem = function(itemName, amount)
        return player:removeItem(itemName, amount)
    end
    player.Functions.GetItemByName = function(itemName)
        return player:getItem(itemName)
    end
    player.Functions.Save = function()
        return player:save()
    end

    playerStore[source] = player
    savedPlayers[identifier] = cloneValue(data)
    debugPrint(("Created player %s (%s)"):format(tostring(source), data.name))
    return player
end

local function removePlayer(source)
    local player = playerStore[source]
    if not player then
        return
    end

    savePlayer(player)
    playerStore[source] = nil
end

local function getPlayer(source)
    if not isValidSource(source) then
        return nil
    end

    return playerStore[source] or createPlayer(source)
end

local function registerServerCallback(name, callback)
    if type(name) ~= "string" or type(callback) ~= "function" then
        return false
    end

    serverCallbacks[name] = callback
    return true
end

local function triggerClientCallback(target, name, callback, ...)
    if not isValidSource(target) or type(name) ~= "string" or type(callback) ~= "function" then
        return false
    end

    clientCallbackSequence = clientCallbackSequence + 1
    local requestId = ("%s:%s"):format(target, clientCallbackSequence)
    pendingClientCallbacks[requestId] = { source = target, callback = callback }
    TriggerClientEvent("sg_core:client:callbackRequest", target, requestId, name, { ... })

    SetTimeout(CALLBACK_TIMEOUT, function()
        local pending = pendingClientCallbacks[requestId]
        if not pending then
            return
        end

        pendingClientCallbacks[requestId] = nil
        pending.callback(nil, "timeout")
    end)

    return true
end

local Core = {
    Name = "sg_core",
    Version = SgCoreVersion,
    Functions = {},
    Players = playerStore
}

Core.Functions.GetPlayer = getPlayer
Core.Functions.GetPlayers = function()
    local players = {}
    for source in pairs(playerStore) do
        players[#players + 1] = source
    end
    return players
end
Core.Functions.GetPlayerByIdentifier = function(identifier)
    for _, player in pairs(playerStore) do
        if player:getIdentifier() == identifier or player.data.license == identifier then
            return player
        end
    end
    return nil
end
Core.Functions.GetPlayerByCitizenId = function(citizenid)
    for _, player in pairs(playerStore) do
        if player.data.citizenid == citizenid then
            return player
        end
    end
    return nil
end
Core.Functions.GetPlayerFromId = Core.Functions.GetPlayer
Core.Functions.CreateCallback = registerServerCallback
Core.Functions.RegisterServerCallback = registerServerCallback
Core.Functions.TriggerClientCallback = triggerClientCallback
Core.Functions.HasPermission = function(source, permission)
    return isValidSource(source) and type(permission) == "string" and IsPlayerAceAllowed(source, permission)
end
Core.Functions.Notify = function(source, message, notificationType)
    if isValidSource(source) then
        TriggerClientEvent("sg_core:client:notify", source, tostring(message), notificationType or "info")
    end
end
Core.Functions.RegisterUsableItem = function(itemName, callback)
    if type(itemName) ~= "string" or type(callback) ~= "function" then
        return false
    end

    usableItems[itemName] = callback
    return true
end
Core.Functions.CreateUseableItem = Core.Functions.RegisterUsableItem
Core.Functions.GetCoreObject = function()
    return Core
end

Core.GetPlayerFromId = Core.Functions.GetPlayer
Core.GetPlayerFromIdentifier = Core.Functions.GetPlayerByIdentifier
Core.GetPlayers = Core.Functions.GetPlayers
Core.GetPlayer = Core.Functions.GetPlayer
Core.RegisterServerCallback = registerServerCallback
Core.TriggerClientCallback = triggerClientCallback
Core.RegisterUsableItem = Core.Functions.RegisterUsableItem

exports("GetCoreObject", function()
    return Core
end)
exports("getSharedObject", function()
    return Core
end)
exports("GetPlayer", getPlayer)
exports("GetPlayers", Core.Functions.GetPlayers)
exports("GetPlayerByIdentifier", Core.Functions.GetPlayerByIdentifier)
exports("RegisterServerCallback", registerServerCallback)
exports("TriggerClientCallback", triggerClientCallback)
exports("RegisterUsableItem", Core.Functions.RegisterUsableItem)

RegisterNetEvent("sg_core:server:requestPlayerData", function()
    local source = source
    local player = getPlayer(source)
    if player then
        sendPlayerData(source, player)
    end
end)

local function sendCallbackResponse(source, responseEvent, responseArguments, success, result)
    local payload = cloneValue(responseArguments or {})
    payload[#payload + 1] = success
    payload[#payload + 1] = result
    TriggerClientEvent(responseEvent, source, table.unpack(payload))
end

local function executeServerCallback(source, requestId, name, args, responseEvent, responseArguments)
    if not isValidSource(source) or type(requestId) ~= "string" or type(name) ~= "string" or type(args) ~= "table" then
        return
    end

    local callback = serverCallbacks[name]
    if not callback then
        sendCallbackResponse(source, responseEvent, responseArguments, false, "callback_not_found")
        return
    end

    local success, result = pcall(callback, source, table.unpack(args))
    if not success then
        print(("[%s] Server callback '%s' failed for %s: %s"):format(RESOURCE_NAME, name, tostring(source), tostring(result)))
        sendCallbackResponse(source, responseEvent, responseArguments, false, "callback_failed")
        return
    end

    sendCallbackResponse(source, responseEvent, responseArguments, true, result)
end

RegisterNetEvent("sg_core:server:callbackRequest", function(requestId, name, args)
    executeServerCallback(source, requestId, name, args, "sg_core:client:callbackResponse", { requestId })
end)

RegisterNetEvent("QBCore:Server:TriggerCallback", function(name, requestId, ...)
    executeServerCallback(source, tostring(requestId), name, { ... }, "QBCore:Client:TriggerCallback", { name, requestId })
end)

RegisterNetEvent("esx:triggerServerCallback", function(name, requestId, ...)
    executeServerCallback(source, tostring(requestId), name, { ... }, "esx:serverCallback", { requestId })
end)

RegisterNetEvent("sg_core:server:clientCallbackResponse", function(requestId, success, result)
    local source = source
    local pending = pendingClientCallbacks[requestId]
    if not pending or pending.source ~= source then
        return
    end

    pendingClientCallbacks[requestId] = nil
    if success then
        pending.callback(result)
    else
        pending.callback(nil, result or "callback_failed")
    end
end)

RegisterNetEvent("sg_core:server:useItem", function(itemName)
    local source = source
    local player = getPlayer(source)
    local callback = type(itemName) == "string" and usableItems[itemName] or nil
    if not player or not callback or not player:hasItem(itemName, 1) then
        return
    end

    local success, errorMessage = pcall(callback, source, player:getItem(itemName))
    if not success then
        print(("[%s] Usable item '%s' failed for %s: %s"):format(RESOURCE_NAME, itemName, tostring(source), tostring(errorMessage)))
    end
end)

AddEventHandler("playerJoining", function()
    local source = source
    local player = createPlayer(source)
    if player then
        sendPlayerData(source, player)
    end
end)

AddEventHandler("playerDropped", function()
    removePlayer(source)
end)

AddEventHandler("onResourceStart", function(resource)
    if resource ~= RESOURCE_NAME then
        return
    end

    loadSavedPlayers()
    Wait(1000)
    for _, playerId in ipairs(GetPlayers()) do
        local source = tonumber(playerId)
        local player = createPlayer(source)
        if player then
            sendPlayerData(source, player)
        end
    end
end)

AddEventHandler("onResourceStop", function(resource)
    if resource == RESOURCE_NAME then
        saveAllPlayers()
    end
end)

CreateThread(function()
    while true do
        Wait(60000)
        saveAllPlayers()
    end
end)

RegisterCommand("sgwho", function(source)
    if source ~= 0 and not IsPlayerAceAllowed(source, "command.sgwho") then
        return
    end

    print(("[%s] Online SG players: %s"):format(RESOURCE_NAME, tostring(#Core.Functions.GetPlayers())))
end, true)
