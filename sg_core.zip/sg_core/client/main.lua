local playerData = {}
local serverCallbacks = {}
local clientCallbacks = {}
local pendingCallbacks = {}
local callbackSequence = 0

local CALLBACK_TIMEOUT <const> = Config.CallbackTimeout

local function copyValue(value)
    if type(value) ~= "table" then
        return value
    end

    local copy = {}
    for key, child in pairs(value) do
        copy[key] = copyValue(child)
    end

    return copy
end

local function triggerServerCallback(name, callback, ...)
    if type(name) ~= "string" or type(callback) ~= "function" then
        return false
    end

    callbackSequence = callbackSequence + 1
    local requestId = tostring(callbackSequence)
    pendingCallbacks[requestId] = callback
    TriggerServerEvent("sg_core:server:callbackRequest", requestId, name, { ... })

    SetTimeout(CALLBACK_TIMEOUT, function()
        local pending = pendingCallbacks[requestId]
        if not pending then
            return
        end

        pendingCallbacks[requestId] = nil
        pending(nil, "timeout")
    end)

    return true
end

local ClientCore = {
    Name = "sg_core",
    Version = SgCoreVersion,
    Functions = {}
}

ClientCore.Functions.GetPlayerData = function()
    return copyValue(playerData)
end
ClientCore.Functions.TriggerCallback = triggerServerCallback
ClientCore.Functions.RegisterClientCallback = function(name, callback)
    if type(name) ~= "string" or type(callback) ~= "function" then
        return false
    end

    clientCallbacks[name] = callback
    return true
end
ClientCore.Functions.Notify = function(message, notificationType)
    TriggerEvent("sg_core:client:notify", tostring(message), notificationType or "info")
end
ClientCore.Functions.GetCoreObject = function()
    return ClientCore
end

ClientCore.GetPlayerData = ClientCore.Functions.GetPlayerData
ClientCore.TriggerServerCallback = triggerServerCallback
ClientCore.ShowNotification = ClientCore.Functions.Notify
ClientCore.GetCoreObject = ClientCore.Functions.GetCoreObject
ClientCore.PlayerData = playerData
ClientCore.RegisterServerCallback = ClientCore.Functions.RegisterClientCallback

exports("GetCoreObject", function()
    return ClientCore
end)
exports("getSharedObject", function()
    return ClientCore
end)
exports("GetPlayerData", ClientCore.Functions.GetPlayerData)
exports("TriggerServerCallback", triggerServerCallback)
exports("RegisterClientCallback", ClientCore.Functions.RegisterClientCallback)
exports("Notify", ClientCore.Functions.Notify)

RegisterNetEvent("sg_core:client:playerLoaded", function(data)
    playerData = copyValue(data or {})
    ClientCore.PlayerData = playerData
    TriggerEvent("sg_core:client:ready", ClientCore.GetPlayerData())
end)

RegisterNetEvent("esx:getSharedObject", function(callback)
    if type(callback) == "function" then
        callback(ClientCore)
    end
end)

RegisterNetEvent("QBCore:Client:GetObject", function(callback)
    if type(callback) == "function" then
        callback(ClientCore)
    end
end)

RegisterNetEvent("sg_core:client:jobUpdated", function(job)
    playerData.job = copyValue(job or {})
    ClientCore.PlayerData = playerData
    TriggerEvent("sg_core:client:jobUpdated", copyValue(playerData.job))
end)

RegisterNetEvent("sg_core:client:notify", function(message, notificationType)
    TriggerEvent("chat:addMessage", {
        color = { 90, 210, 180 },
        args = { "SG", tostring(message) }
    })
end)

local function resolveCallback(requestId, success, result)
    local callback = pendingCallbacks[tostring(requestId)]
    if not callback then
        return
    end

    pendingCallbacks[tostring(requestId)] = nil
    if success then
        callback(result)
    else
        callback(nil, result or "callback_failed")
    end
end

RegisterNetEvent("sg_core:client:callbackResponse", function(requestId, success, result)
    resolveCallback(requestId, success, result)
end)

RegisterNetEvent("QBCore:Client:TriggerCallback", function(name, requestId, success, result)
    resolveCallback(requestId, success, result)
end)

RegisterNetEvent("esx:serverCallback", function(requestId, success, result)
    resolveCallback(requestId, success, result)
end)

RegisterNetEvent("sg_core:client:callbackRequest", function(requestId, name, args)
    local callback = clientCallbacks[name]
    if not callback then
        TriggerServerEvent("sg_core:server:clientCallbackResponse", requestId, false, "callback_not_found")
        return
    end

    local responseCallback = function(result)
        TriggerServerEvent("sg_core:server:clientCallbackResponse", requestId, true, result)
    end

    local success, result = pcall(callback, responseCallback, table.unpack(args or {}))
    if not success then
        TriggerServerEvent("sg_core:server:clientCallbackResponse", requestId, false, "callback_failed")
    elseif result ~= nil then
        responseCallback(result)
    end
end)

AddEventHandler("onClientResourceStart", function(resource)
    if resource ~= GetCurrentResourceName() then
        return
    end

    TriggerServerEvent("sg_core:server:requestPlayerData")
end)
