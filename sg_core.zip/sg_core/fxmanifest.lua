fx_version "cerulean"
game "gta5"
lua54 "yes"

author "SwisserAI"
description "Generated with SwisserAI - standalone roleplay core with ESX, QBCore, Qbox, and ND-shaped compatibility APIs"
version "1.0.0"

provide "qb-core"
provide "es_extended"
provide "qbx_core"
provide "nd-core"

shared_scripts {
    "config/main.lua",
    "shared/main.lua"
}

server_scripts {
    "server/main.lua"
}

client_scripts {
    "client/main.lua"
}
