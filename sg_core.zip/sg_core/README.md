# sg_core

`sg_core` is a standalone roleplay core with no framework dependency. It owns player data, money accounts, jobs, metadata, a small persistent inventory, server/client callbacks, ACE permission checks, and compatibility-shaped facades for ESX, QBCore, Qbox, and ND-style resources.

## Important compatibility note

The `provide` entries in `fxmanifest.lua` let `sg_core` satisfy dependency names when the original core resources are not also installed. This resource does not execute arbitrary third-party framework source or silently rewrite incompatible business logic. Scripts that use undocumented or framework-specific behavior still need a small adapter.

Do not start the original `qb-core`, `es_extended`, `qbx_core`, or `nd-core` alongside `sg_core` unless you intentionally want two competing player stores.

## Included API

- `exports.sg_core:GetCoreObject()`
- `exports.sg_core:getSharedObject()`
- `exports.sg_core:GetPlayer(source)`
- `exports.sg_core:GetPlayers()`
- `exports.sg_core:RegisterServerCallback(name, handler)`
- `exports.sg_core:TriggerClientCallback(source, name, callback, ...)`
- `sg_core:client:playerLoaded`, `esx:playerLoaded`, and `QBCore:Client:OnPlayerLoaded`
- ACE permission checks through `Core.Functions.HasPermission(source, permission)`

Player records are saved to `player-data.json` in this resource. Use a database-backed adapter if your server needs multi-server persistence or large inventories.
