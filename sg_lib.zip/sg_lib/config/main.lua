Config = {
    ScanInterval = 30000,
    ReportFile = "resource-report.json",
    ScanOnStart = true,
    Debug = false
}
