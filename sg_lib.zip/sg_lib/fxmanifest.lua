fx_version "cerulean"
game "gta5"
lua54 "yes"

author "SwisserAI"
description "Generated with SwisserAI - sg_core callback, adapter, and resource inspection library"
version "1.0.0"

dependency "sg_core"

shared_scripts {
    "config/main.lua",
    "shared/main.lua"
}

server_scripts {
    "server/main.lua"
}

client_scripts {
    "client/main.lua"
}
