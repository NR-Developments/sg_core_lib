# sg_lib

`sg_lib` is the companion library for `sg_core`. It provides normalized exports for player access, callbacks, notifications, and resource compatibility inspection.

## Resource detection

The server scans loaded resources using their manifests and dependency metadata. It detects references to `sg_core`, ESX, QBCore, Qbox, and ND Core, stores the result in `resource-report.json`, and exposes it through:

- `exports.sg_lib:GetAdapter(resourceName)`
- `exports.sg_lib:GetResourceFramework(resourceName)`
- `exports.sg_lib:GetResourceAdapters()`
- `exports.sg_lib:RescanResources()`
- `/sgscan` for an ACE-authorized console or administrator

## Why it does not copy arbitrary exports

FiveM resources are isolated Lua runtimes. A library cannot safely read another resource's private Lua locals, clone its exports, or inject replacement globals into an already-running resource. The scanner therefore identifies likely framework usage and exposes normalized SG APIs; existing scripts still need a compatibility adapter when they depend on behavior beyond the documented facade.

The `sg_core` manifest provides the common core resource names when the original cores are absent. Do not run the original core and `sg_core` together unless you deliberately maintain two independent cores.
