local resourceAdapters = {}
local coreObject
local scanRunning = false
local lastScanAt = 0

local RESOURCE_NAME <const> = GetCurrentResourceName()
local FRAMEWORK_ORDER <const> = { "sg", "qbox", "qb", "esx", "nd" }

local function debugPrint(message)
    if Config.Debug then
        print(("[%s] %s"):format(RESOURCE_NAME, message))
    end
end

local function getCore()
    if coreObject then
        return coreObject
    end

    local success, result = pcall(function()
        return exports["sg_core"]:GetCoreObject()
    end)

    if success and result then
        coreObject = result
    end

    return coreObject
end

local function readResourceFile(resourceName, fileName)
    local success, content = pcall(function()
        return LoadResourceFile(resourceName, fileName)
    end)

    if success and type(content) == "string" then
        return content
    end

    return ""
end

local function getResourceMetadataValues(resourceName, key)
    local values = {}
    local success, count = pcall(function()
        return GetNumResourceMetadata(resourceName, key)
    end)

    if not success or not count then
        return values
    end

    for index = 0, count - 1 do
        local metadata = GetResourceMetadata(resourceName, key, index)
        if metadata then
            values[#values + 1] = metadata
        end
    end

    return values
end

local function tableLength(value)
    local count = 0
    for _ in pairs(value) do
        count = count + 1
    end
    return count
end

local function detectFramework(resourceName)
    local manifest = (readResourceFile(resourceName, "fxmanifest.lua") .. "\n" .. readResourceFile(resourceName, "__resource.lua")):lower()
    local dependencies = table.concat(getResourceMetadataValues(resourceName, "dependency"), " "):lower()
        .. " " .. table.concat(getResourceMetadataValues(resourceName, "dependencies"), " "):lower()
    local text = manifest .. " " .. dependencies
    local evidence = {}

    local signatures = {
        sg = { "sg_core", "sgcore" },
        qbox = { "qbx_core", "qbox_core", "qbox" },
        qb = { "qb-core", "qbcore", "qbc.core", "qbcore.functions" },
        esx = { "es_extended", "esx", "esx.getplayerfromid" },
        nd = { "nd-core", "nd_core", "ndcore" }
    }

    local detected = "unknown"
    for _, framework in ipairs(FRAMEWORK_ORDER) do
        for _, signature in ipairs(signatures[framework]) do
            if text:find(signature, 1, true) then
                detected = framework
                evidence[#evidence + 1] = signature
            end
        end

        if detected == framework then
            break
        end
    end

    local state = GetResourceState(resourceName)
    return {
        resource = resourceName,
        framework = detected,
        label = SgLibFrameworks[detected].label,
        state = state,
        evidence = evidence,
        compatible = detected == "sg" or detected == "unknown"
    }
end

local function writeReport()
    local report = {
        generatedAt = os.date("!%Y-%m-%dT%H:%M:%SZ"),
        resourceCount = 0,
        resources = resourceAdapters
    }

    report.resourceCount = tableLength(resourceAdapters)

    local success = SaveResourceFile(RESOURCE_NAME, Config.ReportFile, json.encode(report), -1)
    if not success then
        print(("[%s] Could not write %s"):format(RESOURCE_NAME, Config.ReportFile))
    end
end

local function scanResources()
    if scanRunning then
        return resourceAdapters
    end

    scanRunning = true
    local found = {}
    for index = 0, GetNumResources() - 1 do
        local resourceName = GetResourceByFindIndex(index)
        if resourceName and resourceName ~= RESOURCE_NAME and resourceName ~= "sg_core" then
            found[resourceName] = detectFramework(resourceName)
        end
    end

    resourceAdapters = found
    lastScanAt = os.time()
    scanRunning = false
    writeReport()
    TriggerEvent("sg_lib:server:resourcesScanned", resourceAdapters)
    for _, playerId in ipairs(GetPlayers()) do
        TriggerClientEvent("sg_lib:client:resourcesScanned", tonumber(playerId), resourceAdapters)
    end
    debugPrint(("Scanned %s resources at %s"):format(tostring(tableLength(resourceAdapters)), os.date("!%Y-%m-%dT%H:%M:%SZ", lastScanAt)))
    return resourceAdapters
end

local function getAdapter(resourceName)
    resourceName = resourceName or GetInvokingResource()
    return resourceAdapters[resourceName]
end

exports("GetCoreObject", getCore)
exports("GetAdapter", getAdapter)
exports("GetResourceFramework", function(resourceName)
    local adapter = getAdapter(resourceName)
    return adapter and adapter.framework or "unknown"
end)
exports("GetResourceAdapters", function()
    return resourceAdapters
end)
exports("RescanResources", scanResources)
exports("GetPlayer", function(source)
    local core = getCore()
    return core and core.Functions.GetPlayer(source) or nil
end)
exports("RegisterServerCallback", function(name, callback)
    local core = getCore()
    return core and core.Functions.RegisterServerCallback(name, callback) or false
end)
exports("TriggerClientCallback", function(source, name, callback, ...)
    local core = getCore()
    return core and core.Functions.TriggerClientCallback(source, name, callback, ...) or false
end)
exports("Notify", function(source, message, notificationType)
    local core = getCore()
    if core then
        core.Functions.Notify(source, message, notificationType)
        return true
    end

    return false
end)

RegisterNetEvent("sg_lib:server:rescan", function()
    local source = source
    if source ~= 0 and not IsPlayerAceAllowed(source, "command.sg_lib_rescan") then
        print(("[%s] Refused resource scan request from %s"):format(RESOURCE_NAME, tostring(source)))
        return
    end

    scanResources()
end)

AddEventHandler("onResourceStart", function(resource)
    if resource ~= RESOURCE_NAME then
        return
    end

    if Config.ScanOnStart then
        Wait(1000)
        scanResources()
    end
end)

AddEventHandler("onResourceStart", function(resource)
    if resource ~= RESOURCE_NAME then
        scanResources()
    end
end)

CreateThread(function()
    while true do
        Wait(Config.ScanInterval)
        scanResources()
    end
end)

RegisterCommand("sgscan", function(source)
    if source ~= 0 and not IsPlayerAceAllowed(source, "command.sg_lib_rescan") then
        return
    end

    scanResources()
    print(("[%s] Resource compatibility scan complete. Report: %s"):format(RESOURCE_NAME, Config.ReportFile))
end, true)
