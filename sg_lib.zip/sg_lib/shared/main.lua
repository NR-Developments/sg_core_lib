SgLibVersion = "1.0.0"

SgLibFrameworks = {
    sg = {
        label = "sg_core",
        coreResource = "sg_core"
    },
    esx = {
        label = "ESX",
        coreResource = "es_extended"
    },
    qb = {
        label = "QBCore",
        coreResource = "qb-core"
    },
    qbox = {
        label = "Qbox",
        coreResource = "qbx_core"
    },
    nd = {
        label = "ND Core",
        coreResource = "nd-core"
    },
    unknown = {
        label = "Unknown",
        coreResource = nil
    }
}
