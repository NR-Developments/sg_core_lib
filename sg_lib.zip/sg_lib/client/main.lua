local resourceAdapters = {}
local coreObject

local function getCore()
    if coreObject then
        return coreObject
    end

    local success, result = pcall(function()
        return exports["sg_core"]:GetCoreObject()
    end)

    if success and result then
        coreObject = result
    end

    return coreObject
end

local function triggerServerCallback(name, callback, ...)
    local core = getCore()
    if not core or not core.Functions or not core.Functions.TriggerCallback then
        return false
    end

    return core.Functions.TriggerCallback(name, callback, ...)
end

exports("GetCoreObject", getCore)
exports("GetPlayerData", function()
    local core = getCore()
    return core and core.Functions.GetPlayerData() or {}
end)
exports("TriggerServerCallback", triggerServerCallback)
exports("RegisterClientCallback", function(name, callback)
    local core = getCore()
    if not core or not core.Functions.RegisterClientCallback then
        return false
    end

    return core.Functions.RegisterClientCallback(name, callback)
end)
exports("Notify", function(message, notificationType)
    local core = getCore()
    if core and core.Functions.Notify then
        return core.Functions.Notify(message, notificationType)
    end

    return false
end)
exports("GetResourceFramework", function(resourceName)
    local adapter = resourceAdapters[resourceName]
    return adapter and adapter.framework or "unknown"
end)
exports("GetResourceAdapters", function()
    return resourceAdapters
end)

RegisterNetEvent("sg_lib:client:resourcesScanned", function(adapters)
    resourceAdapters = adapters or {}
end)

AddEventHandler("onClientResourceStart", function(resource)
    if resource ~= GetCurrentResourceName() then
        return
    end

    local core = getCore()
    if core and core.Functions and core.Functions.GetPlayerData then
        TriggerEvent("sg_lib:client:ready", core.Functions.GetPlayerData())
    end
end)
